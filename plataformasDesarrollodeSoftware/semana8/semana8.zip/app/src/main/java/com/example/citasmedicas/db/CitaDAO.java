package com.example.citasmedicas.db;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class CitaDAO {
    Conexion connect = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    public ArrayList<Cita> listing() throws Exception {
        ArrayList<Cita> data =new ArrayList<Cita>();
        String sql = "select * from t_citas order by Id DESC";
        try {
            con = connect.getConnection();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()) {
                Cita temp = new Cita(rs.getInt(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7)
                );
                data.add(temp);
            }
        }
        catch(Exception e){
            throw new Exception(e.getMessage());
        }
        return data;
    }
    public boolean insert(Cita cita)throws Exception {
        boolean result=false;
        try{
            //la llave primaria es autonúmerica por lo cual no hay que ponerla
            String sql="INSERT INTO t_citas(Identificacion,Nombre,Correo,Celular, Fecha, Hora) values(?,?,?,?,?,?)";
            con = connect.getConnection();
            ps = con.prepareStatement(sql);
            ps.setString(1,cita.getIdentificacion());
            ps.setString(2,cita.getNombre());
            ps.setString(3,cita.getCorreo());
            ps.setString(4,cita.getCelular());
            ps.setString(5,cita.getFecha());
            ps.setString(6,cita.getHora());
            int recordsUpdated=ps.executeUpdate();
            //verificamos que si se pudo ingresar un nuevo registro
            if(recordsUpdated==1){
                result = true;
            }
        }
        catch (Exception e){
            throw new Exception(e.getMessage());
        }
        return result;
    }


}
