package com.example.citasmedicas.view;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.citasmedicas.R;
import com.example.citasmedicas.db.Cita;
import com.example.citasmedicas.db.CitaDAO;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class NewActivity extends AppCompatActivity {
    private Toolbar toolbar;
    EditText editTextIdentificacion, editTextNombre,editTextTextCorreo,editTextTetCelular,editTextFecha,editTextHora;
    Button buttonNew;
    CitaDAO dao;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new);
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayShowHomeEnabled(true);
        actionBar.setDisplayHomeAsUpEnabled(true);
        editTextIdentificacion = findViewById(R.id.editTextIdentificacion);
        editTextNombre  = findViewById(R.id.editTextNombre);
        editTextTextCorreo = findViewById(R.id.viewCorreo);
        editTextTetCelular = findViewById(R.id.editTextTetCelular);
        editTextFecha = findViewById(R.id.viewFecha);
        editTextHora = findViewById(R.id.editTextHora);
        dao = new CitaDAO();
        buttonNew = findViewById(R.id.buttonNew);
        setDateTime();

        buttonNew.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                long id = 0;
                try {
                    Cita temp = new Cita(editTextIdentificacion.getText().toString(),editTextNombre.getText().toString(),
                            editTextTextCorreo.getText().toString(),editTextTetCelular.getText().toString(),
                            editTextFecha.getText().toString(),editTextHora.getText().toString());
                    boolean operation = dao.insert(temp);
                    if (operation){
                        Toast.makeText(NewActivity.this,"Registro guardado",Toast.LENGTH_LONG).show();
                        cleanFields();
                    }
                    else{
                        Toast.makeText(NewActivity.this,"Error al insertar registro",Toast.LENGTH_LONG).show();
                    }

                }
                catch (Exception ex){
                    Toast.makeText(NewActivity.this,"Error al insertar registro",Toast.LENGTH_LONG).show();
                }
            }
        });
    }
    // Formatear datos de fecha y hora como sugerencia de sistema
    private void setDateTime() {
        Calendar calendar = Calendar.getInstance();
        Date date = calendar.getTime();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
        String fechaFormateada = dateFormat.format(date);
        editTextFecha.setText(fechaFormateada);
        SimpleDateFormat timeFormat = new SimpleDateFormat("HHmmss");
        String horaFormateada = timeFormat.format(date);
        editTextHora.setText(horaFormateada);
    }
    //Deja en blanco los campos al llenarlos
    private void cleanFields(){
        editTextIdentificacion.setText("");
        editTextNombre.setText("");
        editTextTextCorreo.setText("");
        editTextTetCelular.setText("");
        editTextFecha.setText("");
        editTextHora.setText("");
        setDateTime();
    }
}