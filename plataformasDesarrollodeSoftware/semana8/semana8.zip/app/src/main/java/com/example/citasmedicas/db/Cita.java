package com.example.citasmedicas.db;

public class Cita {
    private int Id;
    private String Identificacion;
    private String Nombre;
    private String Correo;
    private String Celular;
    private String Fecha;
    private String Hora;

    public int getId() {
        return Id;
    }

    public void setId(int id) {
        Id = id;
    }

    public String getIdentificacion() {
        return Identificacion;
    }

    public void setIdentificacion(String identificacion) {
        Identificacion = identificacion;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String nombre) {
        Nombre = nombre;
    }

    public String getCorreo() {
        return Correo;
    }

    public void setCorreo(String correo) {
        Correo = correo;
    }

    public String getCelular() {
        return Celular;
    }

    public void setCelular(String celular) {
        Celular = celular;
    }

    public String getFecha() {
        return Fecha;
    }

    public void setFecha(String fecha) {
        Fecha = fecha;
    }

    public String getHora() {
        return Hora;
    }

    public void setHora(String hora) {
        Hora = hora;
    }
    public  Cita( int _Id,  String _Identificacion, String _Nombre, String _Correo, String _Celular,String _Fecha,String _Hora){
        this.Id = _Id;
        this.Identificacion = _Identificacion;
        this.Nombre = _Nombre;
        this.Correo = _Correo;
        this.Celular = _Celular;
        this.Fecha = _Fecha;
        this.Hora = _Hora;

    }
    public  Cita(  String _Identificacion, String _Nombre, String _Correo, String _Celular,String _Fecha,String _Hora){
        this.Identificacion = _Identificacion;
        this.Nombre = _Nombre;
        this.Correo = _Correo;
        this.Celular = _Celular;
        this.Fecha = _Fecha;
        this.Hora = _Hora;

    }

}
