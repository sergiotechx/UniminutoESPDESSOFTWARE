package com.example.citasmedicas.db;
import android.os.StrictMode;
import android.util.Log;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
public class Conexion {
    Connection con;
    public Connection getConnection() throws Exception {
        try {
            StrictMode.ThreadPolicy policy = new  StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://34.122.165.101:3306/citas";
            String user = "root";
            String password = "1234";
            con = DriverManager.getConnection(url,user,password);
            Log.d("MyTag","Sucessfull connection");
        }catch (SQLException e) {
            throw new Exception(e.getMessage());
        }
        catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return con;
    }
}
