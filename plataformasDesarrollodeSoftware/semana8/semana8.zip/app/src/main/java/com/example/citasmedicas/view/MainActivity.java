package com.example.citasmedicas.view;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import com.example.citasmedicas.R;
import com.example.citasmedicas.adaptadores.ListaCitasAdapter;
import com.example.citasmedicas.db.Cita;
import com.example.citasmedicas.db.CitaDAO;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private Toolbar toolbar;
    CitaDAO dao;
    RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        try {
            dao = new CitaDAO();
            ArrayList<Cita> listaArryCitas = dao.listing();
            ListaCitasAdapter adapter = new ListaCitasAdapter(listaArryCitas);
            recyclerView.setAdapter(adapter);
        } catch (Exception e) {
            Toast.makeText(getApplicationContext(),
                    e.getMessage(), Toast.LENGTH_SHORT);
        }


    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu,menu);
        return super.onCreateOptionsMenu(menu);
    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId() == R.id.nuevaCita){
            newRegister();
            return  true;
        }
        else{
            return super.onOptionsItemSelected(item);
        }
    }
    private void newRegister(){
        Intent intent = new Intent(this, NewActivity.class);
        startActivity(intent);
    }
}