package AvalonX.listadepacientes.adaptadores;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.lang.reflect.Array;
import java.util.ArrayList;

import AvalonX.listadepacientes.R;
import AvalonX.listadepacientes.entidades.Citas;

public class ListaCitasAdapter extends RecyclerView.Adapter<ListaCitasAdapter.CitaViewHolder> {

    ArrayList<Citas> listaCitas;
    public ListaCitasAdapter(ArrayList<Citas> listaCitas){
        this.listaCitas = listaCitas;
    }
    @NonNull
    @Override
    public CitaViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.lista_item_cita,null,false);
        return new CitaViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CitaViewHolder holder, int position) {
        holder.viewIdentificacion.setText(listaCitas.get(position).getIdentificacion());
        holder.viewNombre.setText(listaCitas.get(position).getNombre());
        holder.viewCorreo.setText(listaCitas.get(position).getCorreo());
        holder.viewCelular.setText(listaCitas.get(position).getCelular());
        holder.viewFecha.setText(listaCitas.get(position).getFecha());
        holder.viewHora.setText(listaCitas.get(position).getHora());

    }

    @Override
    public int getItemCount() {
        return listaCitas.size();
    }

    public class CitaViewHolder extends RecyclerView.ViewHolder {
        TextView viewIdentificacion,viewNombre,viewCorreo,viewCelular,viewFecha,viewHora;
        public CitaViewHolder(@NonNull View itemView) {
            super(itemView);
            viewIdentificacion = itemView.findViewById(R.id.viewIdentificacion);
            viewNombre = itemView.findViewById(R.id.viewNombre);
            viewCorreo   = itemView.findViewById(R.id.viewCorreo);
            viewCelular  = itemView.findViewById(R.id.viewCelular);
            viewFecha = itemView.findViewById(R.id.viewFecha);
            viewHora = itemView.findViewById(R.id.viewHora);
        }
    }
}
