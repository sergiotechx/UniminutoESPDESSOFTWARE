package AvalonX.listadepacientes.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import androidx.annotation.Nullable;

import java.util.ArrayList;

import AvalonX.listadepacientes.entidades.Citas;

public class DbCitas extends DbHelper{

    Context context;
    public DbCitas(@Nullable Context context) {
        super(context);
        this.context = context;
    }
    public long insertAppointment(String Identificacion ,String  Nombre, String   Correo, String Celular,String   Fecha, String    Hora) {
        long id = 0;
        try {
            DbHelper dbHelper = new DbHelper(context);
            SQLiteDatabase db = dbHelper.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put("Identificacion",Identificacion);
            values.put("Nombre",Nombre);
            values.put("Correo",Correo);
            values.put("Celular",Celular);
            values.put("Fecha",Fecha);
            values.put("Hora",Hora);
            id = db.insert(TABLE_SCHEDULE,null,values);
            return id;
        }
        catch(Exception ex){
            System.out.print(ex.toString());
        }
        return id;
    }
    public ArrayList<Citas> leerCitas(){
        DbHelper dbHelper = new DbHelper(context);
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ArrayList<Citas> listaCitas = new ArrayList<>();
        Citas cita = null;
        Cursor cursorCitas = null;
        cursorCitas = db.rawQuery("SELECT * FROM " + TABLE_SCHEDULE, null);
        if(cursorCitas.moveToFirst()){
            do{
               cita = new Citas();
               cita.setId(cursorCitas.getInt(0));
               cita.setIdentificacion(cursorCitas.getString(1));
               cita.setNombre(cursorCitas.getString(2));
               cita.setCorreo(cursorCitas.getString(3));
               cita.setCelular(cursorCitas.getString(4));
               cita.setFecha(cursorCitas.getString(5));
               cita.setHora(cursorCitas.getString(6));
               listaCitas.add(cita);
            }while (cursorCitas.moveToNext());
            cursorCitas.close();
        }
        return  listaCitas;
    }
}
