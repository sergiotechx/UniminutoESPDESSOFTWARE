package AvalonX.listadepacientes;



import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import java.util.ArrayList;

import AvalonX.listadepacientes.adaptadores.ListaCitasAdapter;
import AvalonX.listadepacientes.db.DbCitas;
import AvalonX.listadepacientes.db.DbHelper;
import AvalonX.listadepacientes.entidades.Citas;

public class MainActivity extends AppCompatActivity {

    private Toolbar toolbar;
    RecyclerView listaCitas;
    ArrayList<Citas> listaArryCitas;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        listaCitas = findViewById(R.id.listaCitas);
        listaCitas.setLayoutManager(new LinearLayoutManager(this));
        DbCitas dbCitas = new DbCitas(MainActivity.this);
        listaArryCitas = new ArrayList<>();
        ListaCitasAdapter adapter = new ListaCitasAdapter(dbCitas.leerCitas());
        listaCitas.setAdapter(adapter);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_principal,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
       if(item.getItemId() == R.id.menuItemCrearCita){
           newRegister();
           return  true;
       }
       else if (item.getItemId() == R.id.menuItemCrearBD) {
           return createBD();
       }
       else{
           return super.onOptionsItemSelected(item);
       }
    }

    private boolean createBD(){
        boolean succeed = false;
        try {
            DbHelper dbHelper = new DbHelper(MainActivity.this);
            SQLiteDatabase db = dbHelper.getWritableDatabase();
            if(db !=null){
                Toast.makeText(MainActivity.this, "Bases de datos creada", Toast.LENGTH_SHORT).show();
                succeed = true;
            }
            else{
                Toast.makeText(MainActivity.this, "Error al crear la base de datos", Toast.LENGTH_SHORT).show();
            }
        }
        catch( Exception ex){
            System.out.print(ex.toString());
        }
        return  succeed;
    }

    private void newRegister(){
       Intent intent = new Intent(this, NewActivity.class);
       startActivity(intent);
    }
}