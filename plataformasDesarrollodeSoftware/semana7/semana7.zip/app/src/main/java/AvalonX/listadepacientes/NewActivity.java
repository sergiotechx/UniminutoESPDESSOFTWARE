package AvalonX.listadepacientes;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import AvalonX.listadepacientes.db.DbCitas;

public class NewActivity extends AppCompatActivity {
    EditText editTextIdentificacion, editTextNombre,editTextTextCorreo,editTextTetCelular,editTextFecha,editTextHora;
    Button buttonNew;
    private Toolbar toolbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new);
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        editTextIdentificacion = findViewById(R.id.editTextIdentificacion);
        editTextNombre  = findViewById(R.id.editTextNombre);
        editTextTextCorreo = findViewById(R.id.viewCorreo);
        editTextTetCelular = findViewById(R.id.editTextTetCelular);
        editTextFecha = findViewById(R.id.viewFecha);
        editTextHora = findViewById(R.id.editTextHora);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayShowHomeEnabled(true);
        actionBar.setDisplayHomeAsUpEnabled(true);
        setDateTime();
        buttonNew = findViewById(R.id.buttonNew);
        buttonNew.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               long id = 0;
               try {
                    DbCitas dbCitas = new DbCitas(NewActivity.this);
                   id = dbCitas.insertAppointment(editTextIdentificacion.getText().toString(),editTextNombre.getText().toString(),
                           editTextTextCorreo.getText().toString(),editTextTetCelular.getText().toString(),
                           editTextFecha.getText().toString(),editTextHora.getText().toString());
                   if(id > 0){
                       Toast.makeText(NewActivity.this,"Registro guardado",Toast.LENGTH_LONG).show();
                       cleanFields();
                   }
                   else{
                       Toast.makeText(NewActivity.this,"Error al insertar registro",Toast.LENGTH_LONG).show();
                   }
               }
               catch (Exception ex){
                   System.out.print(ex.toString());
               }
            }
        });
    }
// Formatear datos de fecha y hora como sugerencia de sistema
    private void setDateTime() {
        Calendar calendar = Calendar.getInstance();
        Date date = calendar.getTime();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
        String fechaFormateada = dateFormat.format(date);
        editTextFecha.setText(fechaFormateada);
        SimpleDateFormat timeFormat = new SimpleDateFormat("HHmmss");
        String horaFormateada = timeFormat.format(date);
        editTextHora.setText(horaFormateada);
    }
 //Deja en blanco los campos al llenarlos
    private void cleanFields(){
        editTextIdentificacion.setText("");
        editTextNombre.setText("");
        editTextTextCorreo.setText("");
        editTextTetCelular.setText("");
        editTextFecha.setText("");
        editTextHora.setText("");
        setDateTime();
     }
}